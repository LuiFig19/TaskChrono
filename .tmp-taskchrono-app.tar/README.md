TaskChrono – Project & Time Management

Tech Stack: Next.js (App Router), TypeScript, Tailwind CSS, PostgreSQL (Prisma), NextAuth (Google OAuth), Resend.

Setup

1. Copy env.example to .env and fill values (ensure ?schema=taskchrono in DATABASE_URL)
2. npm i
3. npx prisma generate
4. npx prisma migrate dev
5. npm run dev

Scripts

- dev: next dev
- build: next build
- start: next start
