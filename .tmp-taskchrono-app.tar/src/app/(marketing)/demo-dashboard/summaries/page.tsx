export default function DemoSummaries() {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900 p-4 text-slate-200">Weekly Summaries preview</div>
  )
}


