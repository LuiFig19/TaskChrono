export default function DemoInventory() {
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-900 p-4 text-slate-200">Inventory Tracker preview</div>
  )
}


