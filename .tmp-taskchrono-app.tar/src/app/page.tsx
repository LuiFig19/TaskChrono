import LandingPage from './(marketing)/page'

export default function RootIndex() {
	return <LandingPage />
}
